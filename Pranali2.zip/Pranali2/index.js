function myFunction()
var a1=parseInt((document.getElementById('iput1') + document.getElementById('iput1') )/2); var b1=parseInt((document.getElementById('seut1') + document.getElementById('seut1'))/2); var c1=parseInt((document.getElementById('cnsut1') + document.getElementById('cnsut1'))/2); var d1=parseInt((document.getElementById('ebut1') + document.getElementById('ebut1'))/2); var e1=parseInt((document.getElementById('admtut1') +
document.getElementById('admtut1'))/2);
if (a1>20 || b1>20 || c1>20 || d1>20 || e1>20){ alert("Please enter correct value")
}
else
{
var obtain=a1; document.getElementById("ipavg").innerHTML=obtain;
 
var obtain=b1; document.getElementById("seavg").innerHTML=obtain; var obtain=c1; document.getElementById("cnsavg").innerHTML=obtain; var obtain=d1; document.getElementById("ebavg").innerHTML=obtain; var obtain=e1; document.getElementById("admtavg").innerHTML=obtain;
}

var a2=parseInt(document.getElementById('ipavg') + document.getElementById('ipfinal') ); var b2=parseInt(document.getElementById('seavg') + document.getElementById('sefinal')); var c2=parseInt(document.getElementById('cnsavg') + document.getElementById('cnsfinal')); var d2=parseInt(document.getElementById('ebavg') + document.getElementById('ebfinal')); var e2=parseInt(document.getElementById('admtavg') +
document.getElementById('admtfinal'));
if (a2>100 || b2>100 || c2>100 || d2>100 || e2>100){ alert("Please enter correct value")
}
else
{
var obtain1=a; document.getElementById("bookone").innerHTML=obtain1; var obtain1=b; document.getElementById("booktwo").innerHTML=obtain1; var obtain1=c; document.getElementById("bookthree").innerHTML=obtain1; var obtain1=d; document.getElementById("bookfour").innerHTML=obtain1; var obtain1=e; document.getElementById("bookfive").innerHTML=obtain1;
}

function calculate()
{
var N=document.getElementById('N').value; var D=document.getElementById('D').value; var s=document.getElementById('S').value;
var seatno=document.getElementById('seatno').value;


var a=parseInt(document.getElementById('bookone').value); var b=parseInt(document.getElementById('booktwo').value); var c=parseInt(document.getElementById('bookthree').value); var d=parseInt(document.getElementById('bookfour').value); var e=parseInt(document.getElementById('bookfive').value); if (a>100 || b>100 || c>100 || d>100 || e>100){
alert("Please enter correct value")
}
 
else
{
var obtain2=a; document.getElementById("obtain1").innerHTML=obtain2; var obtain2=b; document.getElementById("obtain2").innerHTML=obtain2; var obtain2=c; document.getElementById("obtain3").innerHTML=obtain2; var obtain2=d; document.getElementById("obtain4").innerHTML=obtain2; var obtain2=e; document.getElementById("obtain5").innerHTML=obtain2;
}
var total=a+b+c+d+e; document.getElementById("total").innerHTML=total; var per=(total/500)*100; document.getElementById("per").innerHTML=per; var CGPA=(per/9.5);
document.getElementById("CGPA").innerHTML=CGPA;

if (a>40 && b>40 && c>40 && d>40 && e>40){ document.getElementById("remarks").innerHTML="<span style='color:#292'> Pass;
</span>"
}
else
{

document.getElementById("remarks").innerHTML="<span style='color:#FF0000'> Fail;
</span>";

}
if (a>=80 ){ document.getElementById("grade1").textContent= "O";
}
else if (a>=70 && a<80){ document.getElementById("grade1").textContent= "A";
}
else if (a>=60 && a<70){ document.getElementById("grade1").textContent= "B";
}
else if (a>=55 && a<60){ document.getElementById("grade1").textContent= "C";
}
else if (a>=50 && a<55){ document.getElementById("grade1").textContent= "D";
}
else if (a>=40 && a<50){
 
document.getElementById("grade1").textContent= "E";
}	
else {	
document.getElementById("grade1").textContent=	"F";
}	
if (b>=80 ){	
document.getElementById("grade2").textContent=	"O";
}	
else if (b>=70 && b<80){	
document.getElementById("grade2").textContent=	"A";
}	
else if (b>=60 && b<70){	
document.getElementById("grade2").textContent=	"B";
}	
else if (b>=55 && b<60){	
document.getElementById("grade2").textContent=	"C";
}	
else if (b>=50 && b<55){	
document.getElementById("grade2").textContent=	"D";
}	
else if (b>=40 && b<50){	
document.getElementById("grade2").textContent=	"E";
}	
else {	
document.getElementById("grade2").textContent=	"F";
}	


if (c>=80 ){
document.getElementById("grade3").textContent=	
"O";
}	
else if (c>=70 && c<80){	
document.getElementById("grade3").textContent=	"A";
}	
else if (c>=60 && c<70){	
document.getElementById("grade3").textContent=	"B";
}	
else if (c>=55 && c<60){	
document.getElementById("grade3").textContent=	"C";
}	
else if (c>=50 && c<55){	
document.getElementById("grade3").textContent=	"D";
}	
else if (c>=40 && c<50){	
document.getElementById("grade3").textContent=	"E";
}	
else {	
document.getElementById("grade3").textContent=	"F";
}	
 


if (d>=80 ){
document.getElementById("grade4").textContent=	
"O";
}	
else if (d>=70 && d<80){	
document.getElementById("grade4").textContent=	"A";
}	
else if (d>=60 && d<70){	
document.getElementById("grade4").textContent=	"B";
}	
else if (d>=55 && d<60){	
document.getElementById("grade4").textContent=	"C";
}	
else if (d>=50 && d<55){	
document.getElementById("grade4").textContent=	"D";
}	
else if (d>=40 && d<50){	
document.getElementById("grade4").textContent=	"E";
}	
else {	
document.getElementById("grade4").textContent=	"F";
}	


if (e>=80 ){
document.getElementById("grade5").textContent=	
"O";
}	
else if (e>=70 && e<80){	
document.getElementById("grade5").textContent=	"A";
}	
else if (e>=60 && e<70){	
document.getElementById("grade5").textContent=	"B";
}	
else if (e>=55 && e<60){	
document.getElementById("grade5").textContent=	"C";
}	
else if (e>=50 && e<55){	
document.getElementById("grade5").textContent=	"D";
}	
else if (e>=40 && e<50){	
document.getElementById("grade5").textContent=	"E";
}	
else {	
document.getElementById("grade5").textContent=	"F";
}	
}